# SA2021_Revenue_Prediction_Project
Summer Analytics course Capstone Project
Developed an algorithm to predict the revenue for an advertisement company based on past data using ML and DS.
Used XGBoost and Random forest regression to train the dataset based on the given projections of past revenue.
This project was evaluated on DPhi.
Achieved an RSME score of 130.3059 in the final Hackathon.
